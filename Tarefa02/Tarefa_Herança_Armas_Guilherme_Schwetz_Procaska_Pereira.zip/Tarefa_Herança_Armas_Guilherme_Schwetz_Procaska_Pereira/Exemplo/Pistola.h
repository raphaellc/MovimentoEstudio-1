#pragma once
#include "ArmaBase.h"
class Pistola : public ArmaBase
{
public:
	Pistola();
	~Pistola() {};

	void atacar() override;
	void recarregar() override;
};

