#include "ArmaBase.h"

void ArmaBase::atacar()
{
	cout << "Using: " << id << endl;
	
	if (ammo != 0) {
		if (id == "MOTOSSERRA") {
			cout << "Ammo: Unlimited\n" << endl;
		}
		else {
			ammo--;
			cout << "Ammo: " << ammo << "/" << maxAmmo << endl << endl;
		}
	}

	else {
		cout << "Sem muni��o\n" << endl;
	}	
}

void ArmaBase::recarregar()
{
	if (id == "MOTOSSERRA") {
		cout << "Motosserra � inrecarreg�vel\n" << endl;
	}
	else {
		ammo = maxAmmo;
		cout << getId() << " foi recarregada!\n";
		cout << "Ammo: " << ammo << "/" << maxAmmo << endl << endl;
	}
}
