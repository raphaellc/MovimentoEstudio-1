#include <iostream>
#include <ctime>
#include <string>
#include <cmath>
#include <cstdio>
#include <fstream>
#include <iomanip>
#include "Pistola.h"
#include "Motosserra.h"
#include "Metralhadora.h"
#include "Calibre12.h"

using namespace std;

int main() {
	setlocale(LC_ALL, "ptb");

	char Escolha;
	int Arma;
	
	//Cria��o dos objetos Armas
	ArmaBase * array[4];
	array[pistola] = new Pistola(); 
	array[motosserra] = new Motosserra();
	array[metralhadora] = new Metralhadora();
	array[calibre12] = new Calibre12();

	Arma = pistola;

	//Repeti��o para decidir a a��o at� o programa ser fechado
	do {
		cout << "Escolha a pr�xima a��o: \n- Atirar(A);\n- Trocar Arma(T);\n- Recarregar(R);\n- Sair(S);\nSele��o: ";
		cin >> Escolha;

		//Escolha da a��o do usu�rio
		switch (tolower(Escolha)) {
		case 'a': array[Arma]->atacar();
			break;
		case 't': cout << "Escolha entre Pistola(1), Motosserra(2), Metralhadora(3), Calibre12(4): ";
			cin >> Arma; Arma -= 1;
			if(Arma >= 0 && Arma <= 3){
				cout << "Arma trocada para " << array[Arma]->getId() << "\n" << endl;
			}

			else{
				//Garantia de que escolher� uma arma existente
				do {
					cout << "Arma inexistente! Selecione uma nova:";
					cin >> Arma; Arma -= 1;

				} while (Arma < 0 || Arma > 3);
			}
			break;

		case 'r': array[Arma]->recarregar();
			break;
		}
	} while (tolower(Escolha) != 's');



	system("pause");
	return 0;
}