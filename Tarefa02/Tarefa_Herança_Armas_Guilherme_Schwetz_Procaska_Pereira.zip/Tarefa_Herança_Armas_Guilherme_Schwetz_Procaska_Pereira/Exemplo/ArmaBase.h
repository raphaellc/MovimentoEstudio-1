#pragma once
#include <iostream>
#include <string>

using namespace std;

enum  tipoArma { pistola, motosserra, metralhadora, calibre12 };

class ArmaBase
{
public:
	void atacar();
	void recarregar();
	string getId() { return id; };

protected:
	string id;
	int ammo, maxAmmo;
};

