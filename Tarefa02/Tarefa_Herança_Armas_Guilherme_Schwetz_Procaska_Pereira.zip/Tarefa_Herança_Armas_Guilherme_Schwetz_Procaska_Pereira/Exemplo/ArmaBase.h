#pragma once
#include <iostream>
#include <string>

using namespace std;

enum  tipoArma { pistola, motosserra, metralhadora, calibre12 };

class ArmaBase
{
public:
	virtual void atacar() = 0;
	virtual void recarregar() = 0;
	string getId() { return id; };

protected:
	string id;
	int ammo, maxAmmo;
};

