#pragma once
#include "ArmaBase.h"
class Metralhadora : public ArmaBase
{
public:
	Metralhadora();
	~Metralhadora() {};

};

