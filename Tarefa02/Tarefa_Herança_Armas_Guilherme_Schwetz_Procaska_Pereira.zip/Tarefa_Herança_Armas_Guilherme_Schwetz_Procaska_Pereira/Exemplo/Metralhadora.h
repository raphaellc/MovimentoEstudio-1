#pragma once
#include "ArmaBase.h"
class Metralhadora : public ArmaBase
{
public:
	Metralhadora();
	~Metralhadora() {};

	void atacar() override;
	void recarregar() override;
};

