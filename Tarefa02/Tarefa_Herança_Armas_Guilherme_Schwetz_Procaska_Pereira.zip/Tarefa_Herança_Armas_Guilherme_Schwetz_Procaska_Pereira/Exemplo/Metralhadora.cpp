#include "Metralhadora.h"

Metralhadora::Metralhadora()
{
	id = "METRALHADORA";
	maxAmmo = ammo = 120;
}

void Metralhadora::atacar()
{
	cout << "Using: " << id << endl;

	if (ammo != 0) {
		ammo--;
		cout << "Ammo: " << ammo << "/" << maxAmmo << endl << endl;
	}

	else {
		cout << "Sem muni��o\n" << endl;
	}
}

void Metralhadora::recarregar()
{
	ammo = maxAmmo;
	cout << getId() << " foi recarregada!\n";
	cout << "Ammo: " << ammo << "/" << maxAmmo << endl << endl;
}
