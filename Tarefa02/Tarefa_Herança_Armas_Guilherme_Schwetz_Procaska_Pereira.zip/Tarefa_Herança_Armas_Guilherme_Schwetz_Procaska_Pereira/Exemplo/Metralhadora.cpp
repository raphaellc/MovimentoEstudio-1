#include "Metralhadora.h"

Metralhadora::Metralhadora()
{
	id = "METRALHADORA";
	maxAmmo = ammo = 120;
}
