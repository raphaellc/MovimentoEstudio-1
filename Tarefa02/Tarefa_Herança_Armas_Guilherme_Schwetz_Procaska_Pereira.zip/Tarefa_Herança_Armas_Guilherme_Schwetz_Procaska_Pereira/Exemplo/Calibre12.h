#pragma once
#include "ArmaBase.h"
class Calibre12 : public ArmaBase
{
public:
	Calibre12();
	~Calibre12() {};
};

