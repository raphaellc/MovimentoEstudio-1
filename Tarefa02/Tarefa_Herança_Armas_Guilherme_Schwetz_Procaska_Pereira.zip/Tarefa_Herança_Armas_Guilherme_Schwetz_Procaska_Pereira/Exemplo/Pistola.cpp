#include "Pistola.h"

Pistola::Pistola()
{
	id = "PISTOLA";
	maxAmmo = ammo = 12;
}

void Pistola::atacar()
{
	cout << "Using: " << id << endl;

	if (ammo != 0) {
		ammo--;
		cout << "Ammo: " << ammo << "/" << maxAmmo << endl << endl;
	}

	else {
		cout << "Sem muni��o\n" << endl;
	}
}

void Pistola::recarregar()
{
	ammo = maxAmmo;
	cout << getId() << " foi recarregada!\n";
	cout << "Ammo: " << ammo << "/" << maxAmmo << endl << endl;
}
