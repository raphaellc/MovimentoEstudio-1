#include "Motosserra.h"

Motosserra::Motosserra()
{
	id = "MOTOSSERRA";
	maxAmmo = ammo = -5;
}

void Motosserra::atacar()
{
	cout << "Ammo: Unlimited;" << endl << endl;
}

void Motosserra::recarregar()
{
	cout << "Motosserra � inrecarreg�vel\n" << endl;
}
