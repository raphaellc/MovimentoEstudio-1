#include "Motosserra.h"

Motosserra::Motosserra()
{
	id = "MOTOSSERRA";
	maxAmmo = ammo = -1;
}
