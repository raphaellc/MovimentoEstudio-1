#pragma once
#include "ArmaBase.h"
class Motosserra : public ArmaBase
{
public:
	Motosserra();
	~Motosserra() {};

	void atacar() override;
	void recarregar() override;
};