#include "Calibre12.h"

Calibre12::Calibre12()
{
	id = "CALIBRE12.";
	maxAmmo = ammo = 6;
}

void Calibre12::atacar()
{
	cout << "Using: " << id << endl;

	if (ammo != 0) {
		ammo--;
		cout << "Ammo: " << ammo << "/" << maxAmmo << endl << endl;
	}

	else {
		cout << "Sem muni��o\n" << endl;
	}
}

void Calibre12::recarregar()
{
	ammo = maxAmmo;
	cout << getId() << " foi recarregada!\n";
	cout << "Ammo: " << ammo << "/" << maxAmmo << endl << endl;
}
