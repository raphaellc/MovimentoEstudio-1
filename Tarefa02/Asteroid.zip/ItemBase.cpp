#include "ItemBase.h"

ItemBase::ItemBase()
{
}


ItemBase::~ItemBase()
{
}

void ItemBase::powerUpActive()
{
	//Ter defini��o que 
	//poderia ser �til pra classe derivada
}
