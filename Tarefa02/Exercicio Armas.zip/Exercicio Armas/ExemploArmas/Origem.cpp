#include <iostream> // Entrada/Saida padrao
#include <ctime>
#include <string>
#include <cmath>
#include <cstdio>
#include <fstream> //Trabalha com arquivos
#include <iomanip>
#include "Pistola.h"
#include "Motosserra.h"
#include "windows.h"
#include "Metralhadora.h"
#include "Calibre12.h"
using namespace std;



int main() {
	setlocale(LC_ALL, "ptb");

	ArmaBase array[4];
	tipoArma i;
	array[Pistol] = Pistola();
	array[Motoss] = Motosserra();
	array[Metralha] = Metralhadora();
	array[Doze] = Calibre12();
	bool sair = false;
	
	//
	i = Pistol;
	do {
		char opcao;
		int opcaoArma ;
		cout << "\nArma Equipada:" << array[i].getId() << "\nMuni��o Restante:"<<array[i].getAmmo()<<"\n\nOp��es:\nA.Atirar\nT.Trocar de Arma\nR.Recarregar\nS.Sair\n\nInsira a op��o desejada:";
		cin >> opcao;
		
		opcao = toupper(opcao);
		cout << "\n=========================================================================================================================\n";
		if (opcao == 'T')
		{
			cout << "\nArmas no Invent�rio:\n1.Pistola\n2.Motossera\n3.Metralhadora\n4.Calibre-12\n\nQual arma deseja equipar:";
			cin >> opcaoArma;
			switch (opcaoArma) {

			case 1:i = Pistol; cout << "\nVoc� equipou PISTOLA\n";
				break;
			case 2:i = Motoss; cout << "\nVoc� equipou MOTOSSERRA\n";
				break;
			case 3:i = Metralha; cout << "\nVoc� equipou METRALHA\n";
				break;
			case 4:i = Doze; cout << "\nVoc� equipou CALIBRE-12\n";
				break;
			default:cout << "\nOp��o Inv�lida.\n";
			}
		}
		
		else
		{
			switch (opcao) {

			case 'A':array[i].atacar();
				break;
			case '2': break;


			case 'R':
				array[i].reload();
				
				break;
			case 'S':
				sair = true;
				break;
			default:cout << "\nOp��o Inv�lida.\n";

			};
		}
		
		cout << "\n===========================================================================================================================\n";
	} while (sair == false);

			

	system("pause");
	return 0;
}