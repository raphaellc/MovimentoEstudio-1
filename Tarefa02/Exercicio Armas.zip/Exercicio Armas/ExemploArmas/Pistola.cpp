#include "Pistola.h"

Pistola::Pistola()
{
	id = "PISTOLA";
	maxAmmo = ammo = 12;
}
