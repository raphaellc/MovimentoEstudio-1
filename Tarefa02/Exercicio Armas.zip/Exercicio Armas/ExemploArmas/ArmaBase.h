#pragma once

#include <iostream>
#include <string>
#include<windows.h>


	using namespace std;

	enum  tipoArma { Pistol, Motoss,Metralha,Doze };

	
	
	class ArmaBase
	{
	public:

		void write(string texto,int tempo);
		void atacar();
		int getAmmo() {return ammo; }
		string getId() { return id; }
		void reload();
	protected:
		string id;
		int ammo, maxAmmo;
	};

