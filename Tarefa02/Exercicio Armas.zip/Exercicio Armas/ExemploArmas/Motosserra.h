#pragma once
#include "ArmaBase.h"
class Motosserra : public ArmaBase
{
public:
	Motosserra();
	~Motosserra() {};
};
