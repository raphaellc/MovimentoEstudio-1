#pragma once
#include "ArmaBase.h"
class Pistola : public ArmaBase
{
public:
	Pistola();
	~Pistola() {};
};

