#include "Metralhadora.h"

Metralhadora::Metralhadora()
{
	id = "METRALHADORA";
	maxAmmo = ammo = 30;
}

Metralhadora::~Metralhadora()
{
}
