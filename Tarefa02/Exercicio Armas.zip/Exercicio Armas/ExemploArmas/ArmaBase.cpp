#include "ArmaBase.h"


void ArmaBase::write(string texto, int tempo)
{

	for (int l = 0; l < texto.size(); l++) {
		cout << texto[l];
		Sleep(tempo);
	}

}

void ArmaBase::atacar()
{
	cout << "Using: " << id << endl;

	if (id == "MOTOSSERRA") {
		cout << "Ammo: Unlimited\n";
	}
	else {
		ammo--;
		cout << "Ammo: " << ammo << "/" << maxAmmo << endl;
	}


}

void ArmaBase::reload()
{
	if (id == "MOTOSSERRA")
	{
		cout << "\nMotosserras n�o podem ser recarregadas.\n";

	}
	else
	{
		write("Recarregando", 100); write(". . .", 300); cout << endl;
		ammo = maxAmmo;
	}
	

}
