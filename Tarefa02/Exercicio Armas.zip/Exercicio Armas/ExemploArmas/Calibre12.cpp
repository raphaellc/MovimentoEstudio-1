#include "Calibre12.h"

Calibre12::Calibre12()
{
	id = "CALIBRE-12";
	maxAmmo = ammo = 8;

}

Calibre12::~Calibre12()
{
}
